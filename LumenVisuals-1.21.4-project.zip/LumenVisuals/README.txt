LUMEN VISUALS — Fabric 1.21.4 (клиентский мод, Java 21)

МЕНЮ: RShift (стеклянная панель, тап по пункту — вкл/выкл, ползунок дальности)
КЛАВИШИ: J ESP, K Tracers, U Nametags, L Fullbright (меняются в управлении)

TARGET ESP   — кольцо (бегает вверх-вниз) и/или 3D-бокс на цели.
               Цель = на кого смотришь или кого бьёшь, держится несколько секунд.
TARGET HUD   — glass-панель: голова, ник, плавное HP, дистанция.
WORLD VISUALS— время суток, туман/цвет неба, частицы вокруг, цветной оверлей, виньетка.

НАСТРОЙКА ЧЕРЕЗ ЧАТ (с точкой, без слеша, или /lumen ...):
  .lumen help
  .thud on|off|x N|y N|scale F|style glass|flat|color HEX|skin on|off|hold SEC|reset
  .tesp on|off|style ring|box|both|color HEX
  .world on|off|preset newyear|sunset|aurora|sakura|off
  .world fog <старт%> <конец%> | fogcolor HEX | time day|sunset|night|0-24000|off
  .world particles snow|sparkle|magic|sakura|ash|glow|electric|off | count N
  .world tint HEX [альфа] | vignette on|off
Примеры:  .thud x 80   .thud y -30   .thud scale 1.3   .tesp style both   .world preset sunset

Всё хранится в config/lumenvisuals.json.

СБОРКА: залить zip в репозиторий GitHub (workflow build.yml уже есть) -> Actions -> Artifacts.
