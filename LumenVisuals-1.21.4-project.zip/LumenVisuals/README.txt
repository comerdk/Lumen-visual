LUMEN VISUALS — Fabric 1.21.4 (клиентский мод, Java 21)

Модули (клавиши меняются в Управление -> Lumen Visuals):
  RShift  — меню Lumen (тап по пункту — вкл/выкл, ползунок дальности)
  J  ESP        — боксы + полоска HP
  K  Tracers    — линии к целям
  U  Nametags   — имя, HP, дистанция
  L  Fullbright — яркость на максимум

Настройки: config/lumenvisuals.json (дальность, фильтры игроков/мобов, цвета, гамма).

СБОРКА В JAR:
  1. Открой папку в IntelliJ IDEA (Open -> build.gradle), Gradle JVM = Java 21.
  2. Дождись импорта, затем Gradle -> Tasks -> build -> build
     (или в терминале: gradlew build — скопируй gradlew, gradlew.bat и
      gradle/wrapper/gradle-wrapper.jar из своего другого мода).
  3. Готовый мод: build/libs/lumen-visuals-1.0.0.jar -> в папку mods
     (нужен Fabric Loader 0.16.10+ и Fabric API для 1.21.4).

Если Gradle не находит версию Fabric API / Yarn — поставь ближайшую
с https://fabricmc.net/develop (поля в gradle.properties).

БЕЗ ПК (телефон): залей этот zip в репозиторий GitHub вместе с файлом
.github/workflows/build.yml (текст ниже) и скачай jar из Actions -> Artifacts.
