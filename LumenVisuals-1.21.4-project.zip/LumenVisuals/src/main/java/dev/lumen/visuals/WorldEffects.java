package dev.lumen.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.Random;

/** «Красивый мир»: время суток, частицы вокруг игрока, цветной оверлей и виньетка. Туман — в BackgroundRendererMixin. */
public final class WorldEffects {
    private static final Random RNG = new Random();

    private WorldEffects() {}

    /** Раз в кадр: фиксируем время суток (сервер его сбрасывает, поэтому каждый кадр). */
    public static void frame(MinecraftClient mc) {
        LumenConfig c = LumenConfig.get();
        if (!c.world || !c.worldTime || mc.world == null) return;
        mc.world.getLevelProperties().setTimeOfDay(c.worldTimeTicks);
    }

    /** Раз в тик: пара частиц вокруг игрока. */
    public static void tick(MinecraftClient mc) {
        LumenConfig c = LumenConfig.get();
        if (!c.world || c.particleCount <= 0 || mc.world == null || mc.player == null || mc.isPaused()) return;
        ParticleEffect fx = effect(c.particleType);
        if (fx == null) return;

        boolean falling = c.particleType.equals("snow") || c.particleType.equals("sakura") || c.particleType.equals("ash");
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        for (int i = 0; i < c.particleCount; i++) {
            double x = px + (RNG.nextDouble() - 0.5) * 28;
            double y = py + RNG.nextDouble() * 9 - 1;
            double z = pz + (RNG.nextDouble() - 0.5) * 28;
            double vy = falling ? -0.03 - RNG.nextDouble() * 0.03 : (RNG.nextDouble() - 0.3) * 0.02;
            mc.world.addParticle(fx, x, y, z, (RNG.nextDouble() - 0.5) * 0.02, vy, (RNG.nextDouble() - 0.5) * 0.02);
        }
    }

    /** Лёгкий цветной оверлей + виньетка. */
    public static void overlay(DrawContext c, MinecraftClient mc, LumenConfig cfg) {
        if (!cfg.world) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        if (cfg.tintAlpha > 0) {
            c.fill(0, 0, sw, sh, (cfg.tintAlpha << 24) | cfg.tintRgb);
        }
        if (cfg.vignette) {
            int h = sh / 5;
            c.fillGradient(0, 0, sw, h, 0x66100430, 0x00100430);
            c.fillGradient(0, sh - h, sw, sh, 0x00100430, 0x66100430);
        }
    }

    private static ParticleEffect effect(String name) {
        return switch (name) {
            case "snow" -> ParticleTypes.SNOWFLAKE;
            case "sparkle" -> ParticleTypes.END_ROD;
            case "magic" -> ParticleTypes.ENCHANT;
            case "sakura" -> ParticleTypes.CHERRY_LEAVES;
            case "ash" -> ParticleTypes.WHITE_ASH;
            case "glow" -> ParticleTypes.GLOW;
            case "electric" -> ParticleTypes.ELECTRIC_SPARK;
            default -> null;
        };
    }
}
