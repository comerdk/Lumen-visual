package dev.lumen.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

/** Target HUD: glass-панель с головой, ником, плавной полоской HP и дистанцией. Настраивается командами в чате. */
public final class TargetHud {
    private static final int W = 140, H = 46;

    private static float anim, shownHp;
    private static long lastNs = System.nanoTime();
    private static LivingEntity last;

    private TargetHud() {}

    public static void render(DrawContext c, MinecraftClient mc, LumenConfig cfg) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1_000_000_000f);
        lastNs = now;

        LivingEntity t = cfg.thud ? TargetTracker.get() : null;
        if (t != null) {
            if (t != last) {
                last = t;
                shownHp = t.getHealth();
            }
            anim = Math.min(1f, anim + dt * 6f);
        } else {
            anim = Math.max(0f, anim - dt * 6f);
            if (anim < 0.05f) {
                last = null;
                return;
            }
        }
        if (last == null || anim < 0.05f) return;

        LivingEntity e = last;
        float k = anim;
        float max = Math.max(1f, e.getMaxHealth());
        shownHp += (e.getHealth() - shownHp) * Math.min(1f, dt * 8f);
        float ratio = MathHelper.clamp(shownHp / max, 0f, 1f);

        TextRenderer f = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = cfg.thudArgb;

        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(sw / 2f + cfg.thudX, sh / 2f + cfg.thudY, 0f);
        float s = cfg.thudScale * (0.9f + 0.1f * k);
        m.scale(s, s, 1f);

        // фон
        if (!"flat".equals(cfg.thudStyle)) {
            c.fill(-2, -2, W + 2, H + 2, a(0x33000000, k));
            c.fillGradient(0, 0, W, H, a(0xCC5B2BB8, k), a(0xCC1E0A4A, k));
            c.fillGradient(0, 0, W, H / 3, a(0x30FFFFFF, k), a(0x00FFFFFF, k));
            border(c, 0, 0, W, H, a(0xAAE6D2FF, k));
        } else {
            c.fill(0, 0, W, H, a(0xDD14082E, k));
            c.fill(0, 0, 2, H, a(accent, k));
        }

        // голова / буква
        int fx = 6, fy = 7, fs = 32;
        c.fill(fx - 1, fy - 1, fx + fs + 1, fy + fs + 1, a(accent, k));
        String name = e.getName().getString();
        if (cfg.thudSkin && e instanceof AbstractClientPlayerEntity p) {
            PlayerSkinDrawer.draw(c, p.getSkinTextures(), fx, fy, fs);
        } else {
            c.fill(fx, fy, fx + fs, fy + fs, a(0xFF2A0E6B, k));
            String letter = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
            c.drawCenteredTextWithShadow(f, letter, fx + fs / 2, fy + fs / 2 - 4, a(0xFFFFFFFF, k));
        }

        // ник
        if (name.length() > 14) name = name.substring(0, 13) + "…";
        c.drawText(f, name, 44, 7, a(0xFFFFFFFF, k), true);

        // HP бар
        int bx = 44, by = 20, bw = W - 52, bh = 6;
        c.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, a(0x99000000, k));
        int fw = (int) (bw * ratio);
        int hpCol = 0xFF000000 | MathHelper.hsvToRgb(ratio / 3f, 0.85f, 1f);
        c.fill(bx, by, bx + fw, by + bh, a(hpCol, k));
        c.fill(bx, by, bx + fw, by + 1, a(0x55FFFFFF, k));

        // HP / дистанция
        int hp = (int) Math.ceil(e.getHealth());
        int absorb = (int) Math.ceil(e.getAbsorptionAmount());
        String hpText = hp + "/" + (int) max + (absorb > 0 ? " +" + absorb : "");
        c.drawText(f, hpText, 44, 30, a(0xFFE6D2FF, k), false);
        String dist = (Math.round(mc.player.distanceTo(e) * 10) / 10f) + "m";
        c.drawText(f, dist, W - 6 - f.getWidth(dist), 30, a(0xFFD9B8FF, k), false);

        // акцентная линия снизу
        c.fill(0, H - 2, (int) (W * ratio), H, a(accent, k));

        m.pop();
    }

    private static int a(int argb, float k) {
        int alpha = (int) (((argb >>> 24) & 0xFF) * k);
        return (alpha << 24) | (argb & 0x00FFFFFF);
    }

    private static void border(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color);
        c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1, x1 + 1, y2, color);
        c.fill(x2 - 1, y1, x2, y2, color);
    }
}
