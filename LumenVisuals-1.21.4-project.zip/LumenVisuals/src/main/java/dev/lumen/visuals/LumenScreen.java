package dev.lumen.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Меню Lumen на RShift: glass-панель, тап по пункту — вкл/выкл, ползунок дальности. */
public class LumenScreen extends Screen {
    private static final int W = 440, COLW = 205, HEADER = 14, TOGGLE = 20, SLIDER = 32;
    private static final int MIN_RANGE = 16, MAX_RANGE = 256;

    private static final class Row {
        final int kind; // 0 заголовок, 1 переключатель, 2 ползунок
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Row(int kind, String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.kind = kind;
            this.label = label;
            this.get = get;
            this.set = set;
        }

        int height() {
            return kind == 0 ? HEADER : kind == 1 ? TOGGLE : SLIDER;
        }
    }

    private record Placed(Row row, int x, int y, int w) {}

    private final List<Placed> placed = new ArrayList<>();
    private int px, py, ph;
    private boolean dragging;

    public LumenScreen() {
        super(Text.literal("Lumen Visuals"));
    }

    @Override
    protected void init() {
        LumenConfig c = LumenConfig.get();

        List<Row> left = new ArrayList<>();
        left.add(new Row(0, "Модули", null, null));
        left.add(new Row(1, "ESP", () -> c.esp, v -> c.esp = v));
        left.add(new Row(1, "Tracers", () -> c.tracers, v -> c.tracers = v));
        left.add(new Row(1, "Nametags + HP", () -> c.nametags, v -> c.nametags = v));
        left.add(new Row(1, "Fullbright", () -> c.fullbright, v -> c.fullbright = v));
        left.add(new Row(1, "Target ESP", () -> c.tesp, v -> c.tesp = v));
        left.add(new Row(1, "Target HUD", () -> c.thud, v -> c.thud = v));
        left.add(new Row(1, "World visuals", () -> c.world, v -> c.world = v));
        left.add(new Row(0, "HUD", null, null));
        left.add(new Row(1, "Список модулей", () -> c.hud, v -> c.hud = v));
        left.add(new Row(1, "Дистанция в нике", () -> c.showDistance, v -> c.showDistance = v));
        left.add(new Row(1, "Tracers из прицела", () -> c.tracersFromCrosshair, v -> c.tracersFromCrosshair = v));

        List<Row> right = new ArrayList<>();
        right.add(new Row(0, "Цели", null, null));
        right.add(new Row(1, "Игроки", () -> c.espPlayers, v -> c.espPlayers = v));
        right.add(new Row(1, "Враждебные мобы", () -> c.espHostile, v -> c.espHostile = v));
        right.add(new Row(1, "Мирные мобы", () -> c.espPassive, v -> c.espPassive = v));
        right.add(new Row(1, "Невидимые", () -> c.showInvisible, v -> c.showInvisible = v));
        right.add(new Row(0, "Дальность", null, null));
        right.add(new Row(2, "", null, null));

        int hl = 0, hr = 0;
        for (Row r : left) hl += r.height();
        for (Row r : right) hr += r.height();
        ph = 30 + Math.max(hl, hr) + 20;
        px = (width - W) / 2;
        py = Math.max(4, (height - ph) / 2);

        placed.clear();
        place(left, px + 10);
        place(right, px + 10 + COLW + 10);
    }

    private void place(List<Row> col, int x) {
        int y = py + 28;
        for (Row r : col) {
            placed.add(new Placed(r, x, y, COLW));
            y += r.height();
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);

        // glass-панель
        ctx.fill(px - 2, py - 2, px + W + 2, py + ph + 2, 0x33000000);
        ctx.fillGradient(px, py, px + W, py + ph, 0xCC5B2BB8, 0xCC1E0A4A);
        ctx.fillGradient(px, py, px + W, py + ph / 3, 0x30FFFFFF, 0x00FFFFFF);
        border(ctx, px, py, px + W, py + ph, 0xAAE6D2FF);

        ctx.drawCenteredTextWithShadow(textRenderer, "LUMEN  Visuals", px + W / 2, py + 9, 0xFFFFFFFF);

        LumenConfig cfg = LumenConfig.get();
        for (Placed p : placed) {
            Row r = p.row();
            int x = p.x(), y = p.y(), w = p.w();
            boolean hover = mx >= x && mx < x + w && my >= y && my < y + r.height();

            if (r.kind == 0) {
                ctx.drawText(textRenderer, r.label, x + 2, y + 2, 0xFFD9B8FF, false);
                ctx.fill(x, y + 12, x + w, y + 13, 0x44FFFFFF);
            } else if (r.kind == 1) {
                if (hover) ctx.fill(x, y, x + w, y + TOGGLE - 1, 0x22FFFFFF);
                ctx.drawText(textRenderer, r.label, x + 4, y + 6, 0xFFFFFFFF, true);
                boolean on = r.get.getAsBoolean();
                int sx = x + w - 30;
                ctx.fill(sx, y + 4, sx + 26, y + 16, on ? 0xFFB388FF : 0x55FFFFFF);
                int kx = on ? sx + 15 : sx + 2;
                ctx.fill(kx, y + 6, kx + 9, y + 14, 0xFFFFFFFF);
            } else {
                ctx.drawText(textRenderer, "Дальность: " + cfg.range + " м", x + 4, y + 2, 0xFFFFFFFF, true);
                float f = (cfg.range - MIN_RANGE) / (float) (MAX_RANGE - MIN_RANGE);
                int bx0 = x + 4, bx1 = x + w - 4, by = y + 18;
                ctx.fill(bx0, by, bx1, by + 4, 0x55FFFFFF);
                int kx = bx0 + (int) ((bx1 - bx0) * f);
                ctx.fill(bx0, by, kx, by + 4, 0xFFB388FF);
                ctx.fill(kx - 3, by - 3, kx + 3, by + 7, 0xFFFFFFFF);
            }
        }

        ctx.drawCenteredTextWithShadow(textRenderer, "RShift — закрыть  •  чат: .lumen help",
                px + W / 2, py + ph - 14, 0xAAD9B8FF);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (Placed p : placed) {
                Row r = p.row();
                if (mx < p.x() || mx >= p.x() + p.w() || my < p.y() || my >= p.y() + r.height()) continue;
                if (r.kind == 1) {
                    r.set.accept(!r.get.getAsBoolean());
                    LumenConfig.get().save();
                    return true;
                } else if (r.kind == 2) {
                    dragging = true;
                    setRange(mx, p);
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            for (Placed p : placed) if (p.row().kind == 2) setRange(mx, p);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging) {
            dragging = false;
            LumenConfig.get().save();
        }
        return super.mouseReleased(mx, my, button);
    }

    private void setRange(double mx, Placed p) {
        float f = MathHelper.clamp((float) ((mx - (p.x() + 4)) / (p.w() - 8)), 0f, 1f);
        int v = Math.round((MIN_RANGE + f * (MAX_RANGE - MIN_RANGE)) / 8f) * 8;
        LumenConfig.get().range = MathHelper.clamp(v, MIN_RANGE, MAX_RANGE);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        LumenConfig.get().save();
    }

    private static void border(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color);
        c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1, x1 + 1, y2, color);
        c.fill(x2 - 1, y1, x2, y2, color);
    }
}
