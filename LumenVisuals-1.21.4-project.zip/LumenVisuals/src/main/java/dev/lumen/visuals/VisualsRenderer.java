package dev.lumen.visuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

/**
 * 2D-визуалы: сущности проецируются в экранные координаты (без кастомных render layer'ов,
 * без лишних аллокаций в цикле) и рисуются через DrawContext в HUD.
 */
public final class VisualsRenderer {
    private static final int SHADOW = 0xAA000000;

    private static final Matrix4f PROJ = new Matrix4f();
    private static final Quaternionf ROT_INV = new Quaternionf();
    private static final Vector3f TMP3 = new Vector3f();
    private static final Vector4f TMP4 = new Vector4f();
    private static final float[] SCR = new float[2];
    private static final float[] BOX = new float[4]; // minX, minY, maxX, maxY

    private static double camX, camY, camZ;
    private static float tickDelta;
    private static boolean ready;

    private VisualsRenderer() {}

    /** Раз в кадр забираем матрицу проекции и поворот камеры. */
    public static void capture(WorldRenderContext ctx) {
        Matrix4f p = ctx.projectionMatrix();
        if (p == null) return;
        PROJ.set(p);
        ROT_INV.set(ctx.camera().getRotation()).conjugate();
        Vec3d pos = ctx.camera().getPos();
        camX = pos.x;
        camY = pos.y;
        camZ = pos.z;
        tickDelta = ctx.tickCounter().getTickDelta(false);
        ready = true;
    }

    public static void render(DrawContext c, RenderTickCounter counter) {
        LumenConfig cfg = LumenConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || mc.options.hudHidden) return;

        if (cfg.hud) drawHud(c, mc, cfg);
        if (!ready || !(cfg.esp || cfg.tracers || cfg.nametags)) return;

        TextRenderer font = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        double rangeSq = (double) cfg.range * cfg.range;
        float tracerX = sw / 2f;
        float tracerY = cfg.tracersFromCrosshair ? sh / 2f : sh;

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity le) || e instanceof ArmorStandEntity) continue;
            if (!cfg.showInvisible && e.isInvisible()) continue;

            int color = colorFor(e, cfg);
            if (color == 0) continue;

            double px = MathHelper.lerp(tickDelta, e.lastRenderX, e.getX());
            double py = MathHelper.lerp(tickDelta, e.lastRenderY, e.getY());
            double pz = MathHelper.lerp(tickDelta, e.lastRenderZ, e.getZ());

            double dx = px - camX, dy = py - camY, dz = pz - camZ;
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq > rangeSq) continue;

            if (!projectBox(e.getBoundingBox(), px - e.getX(), py - e.getY(), pz - e.getZ(), sw, sh)) continue;

            int x1 = (int) BOX[0], y1 = (int) BOX[1], x2 = (int) BOX[2], y2 = (int) BOX[3];
            if (x2 < 0 || y2 < 0 || x1 > sw || y1 > sh) continue;

            if (cfg.esp) {
                outline(c, x1, y1, x2, y2, color);
                float max = Math.max(1f, le.getMaxHealth());
                float ratio = MathHelper.clamp(le.getHealth() / max, 0f, 1f);
                int bx = x1 - 5;
                int filled = (int) ((y2 - y1) * ratio);
                c.fill(bx - 1, y1 - 1, bx + 3, y2 + 1, SHADOW);
                c.fill(bx, y2 - filled, bx + 2, y2, 0xFF000000 | MathHelper.hsvToRgb(ratio / 3f, 1f, 1f));
            }

            if (cfg.tracers) {
                line(c, tracerX, tracerY, (x1 + x2) / 2f, y2, (color & 0x00FFFFFF) | 0xCC000000);
            }

            if (cfg.nametags) {
                int hp = (int) Math.ceil(le.getHealth());
                int abs = (int) Math.ceil(le.getAbsorptionAmount());
                StringBuilder sb = new StringBuilder(e.getName().getString()).append(' ').append(hp);
                if (abs > 0) sb.append('+').append(abs);
                if (cfg.showDistance) sb.append(" [").append((int) Math.sqrt(distSq)).append("m]");
                String label = sb.toString();
                int tx = (int) ((x1 + x2) / 2f - font.getWidth(label) / 2f);
                int ty = y1 - font.fontHeight - 3;
                c.fill(tx - 2, ty - 1, tx + font.getWidth(label) + 2, ty + font.fontHeight, 0x66000000);
                c.drawText(font, label, tx, ty, 0xFFFFFFFF, true);
            }
        }
    }

    /** Watermark слева сверху + список включённых модулей справа сверху. */
    private static void drawHud(DrawContext c, MinecraftClient mc, LumenConfig cfg) {
        TextRenderer f = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();

        // watermark
        int w = f.getWidth("Lumen") + 12;
        int h = f.fontHeight + 6;
        c.fillGradient(4, 4, 4 + w, 4 + h, 0xCC7A3FE0, 0xCC2A0E6B);
        c.fill(4, 4, 6, 4 + h, 0xFFE6D2FF);
        c.drawText(f, "Lumen", 11, 7, 0xFFFFFFFF, true);

        // список модулей
        String[] names = {"ESP", "Tracers", "Nametags", "Fullbright"};
        boolean[] on = {cfg.esp, cfg.tracers, cfg.nametags, cfg.fullbright};
        int y = 4;
        for (int i = 0; i < names.length; i++) {
            if (!on[i]) continue;
            int rw = f.getWidth(names[i]) + 10;
            int x = sw - rw - 4;
            c.fill(x, y, x + rw, y + f.fontHeight + 3, 0x88150535);
            c.fill(x + rw - 2, y, x + rw, y + f.fontHeight + 3, 0xFFB388FF);
            c.drawText(f, names[i], x + 4, y + 2, 0xFFE6D2FF, true);
            y += f.fontHeight + 3;
        }
    }

    private static int colorFor(Entity e, LumenConfig cfg) {
        if (e instanceof PlayerEntity) return cfg.espPlayers ? cfg.playerArgb : 0;
        if (e instanceof Monster) return cfg.espHostile ? cfg.hostileArgb : 0;
        return cfg.espPassive ? cfg.passiveArgb : 0;
    }

    private static boolean project(double x, double y, double z, int sw, int sh) {
        TMP3.set((float) (x - camX), (float) (y - camY), (float) (z - camZ));
        ROT_INV.transform(TMP3);
        TMP4.set(TMP3.x, TMP3.y, TMP3.z, 1f);
        PROJ.transform(TMP4);
        if (TMP4.w <= 0.01f) return false;
        float nx = TMP4.x / TMP4.w;
        float ny = TMP4.y / TMP4.w;
        SCR[0] = (nx * 0.5f + 0.5f) * sw;
        SCR[1] = (1f - (ny * 0.5f + 0.5f)) * sh;
        return true;
    }

    private static boolean projectBox(Box b, double ox, double oy, double oz, int sw, int sh) {
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
        float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = ((i & 1) == 0 ? b.minX : b.maxX) + ox;
            double y = ((i & 2) == 0 ? b.minY : b.maxY) + oy;
            double z = ((i & 4) == 0 ? b.minZ : b.maxZ) + oz;
            if (!project(x, y, z, sw, sh)) return false;
            if (SCR[0] < minX) minX = SCR[0];
            if (SCR[0] > maxX) maxX = SCR[0];
            if (SCR[1] < minY) minY = SCR[1];
            if (SCR[1] > maxY) maxY = SCR[1];
        }
        BOX[0] = minX;
        BOX[1] = minY;
        BOX[2] = maxX;
        BOX[3] = maxY;
        return true;
    }

    private static void outline(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        // тень
        c.fill(x1 - 1, y1 - 1, x2 + 2, y1 + 2, SHADOW);
        c.fill(x1 - 1, y2 - 1, x2 + 2, y2 + 2, SHADOW);
        c.fill(x1 - 1, y1 - 1, x1 + 2, y2 + 2, SHADOW);
        c.fill(x2 - 1, y1 - 1, x2 + 2, y2 + 2, SHADOW);
        // цвет
        c.fill(x1, y1, x2 + 1, y1 + 1, color);
        c.fill(x1, y2, x2 + 1, y2 + 1, color);
        c.fill(x1, y1, x1 + 1, y2 + 1, color);
        c.fill(x2, y1, x2 + 1, y2 + 1, color);
    }

    private static void line(DrawContext c, float x1, float y1, float x2, float y2, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f) return;
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(x1, y1, 0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        c.fill(0, 0, (int) len, 1, color);
        m.pop();
    }
}
