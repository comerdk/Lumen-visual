package dev.lumen.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class LumenVisualsClient implements ClientModInitializer {
    private static final String CATEGORY = "key.categories.lumenvisuals";

    private KeyBinding kEsp, kTracers, kNametags, kFullbright, kMenu;

    @Override
    public void onInitializeClient() {
        LumenConfig.load();

        kEsp = key("esp", GLFW.GLFW_KEY_J);
        kTracers = key("tracers", GLFW.GLFW_KEY_K);
        kFullbright = key("fullbright", GLFW.GLFW_KEY_L);
        kNametags = key("nametags", GLFW.GLFW_KEY_U);
        kMenu = key("menu", GLFW.GLFW_KEY_RIGHT_SHIFT);

        WorldRenderEvents.START.register(VisualsRenderer::capture);
        HudRenderCallback.EVENT.register(VisualsRenderer::render);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private static KeyBinding key(String id, int code) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.lumenvisuals." + id, InputUtil.Type.KEYSYM, code, CATEGORY));
    }

    private void tick(MinecraftClient mc) {
        LumenConfig c = LumenConfig.get();
        while (kMenu.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new LumenScreen());
        }
        while (kEsp.wasPressed()) { c.esp = !c.esp; notify(mc, "ESP", c.esp, c); }
        while (kTracers.wasPressed()) { c.tracers = !c.tracers; notify(mc, "Tracers", c.tracers, c); }
        while (kNametags.wasPressed()) { c.nametags = !c.nametags; notify(mc, "Nametags", c.nametags, c); }
        while (kFullbright.wasPressed()) { c.fullbright = !c.fullbright; notify(mc, "Fullbright", c.fullbright, c); }
    }

    private static void notify(MinecraftClient mc, String name, boolean on, LumenConfig c) {
        c.save();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(name + ": " + (on ? "ON" : "OFF"))
                    .formatted(on ? Formatting.LIGHT_PURPLE : Formatting.GRAY), true);
        }
    }
}
