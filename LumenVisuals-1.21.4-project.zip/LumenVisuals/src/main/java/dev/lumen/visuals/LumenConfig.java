package dev.lumen.visuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Настройки хранятся в config/lumenvisuals.json */
public final class LumenConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static LumenConfig instance = new LumenConfig();

    // модули
    public boolean esp = true;
    public boolean tracers = true;
    public boolean nametags = true;
    public boolean fullbright = true;

    // фильтры
    public boolean espPlayers = true;
    public boolean espHostile = true;
    public boolean espPassive = false;
    public boolean showInvisible = true;
    public boolean showDistance = true;
    public boolean hud = true;
    public boolean tracersFromCrosshair = false;

    // параметры
    public int range = 128;
    public double fullbrightGamma = 100.0;

    // цвета (hex RRGGBB)
    public String playerColor = "B388FF";
    public String hostileColor = "FF5555";
    public String passiveColor = "55FF99";

    public transient int playerArgb, hostileArgb, passiveArgb;

    public static LumenConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("lumenvisuals.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                LumenConfig c = GSON.fromJson(Files.readString(p), LumenConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) {
        }
        instance.recolor();
        instance.save();
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }

    private void recolor() {
        playerArgb = parse(playerColor, 0xB388FF);
        hostileArgb = parse(hostileColor, 0xFF5555);
        passiveArgb = parse(passiveColor, 0x55FF99);
        if (range < 8) range = 8;
    }

    private static int parse(String s, int def) {
        try {
            return 0xFF000000 | (Integer.parseInt(s.replace("#", ""), 16) & 0xFFFFFF);
        } catch (Exception e) {
            return 0xFF000000 | def;
        }
    }
}
