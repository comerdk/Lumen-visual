package dev.lumen.visuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Настройки хранятся в config/lumenvisuals.json */
public final class LumenConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static LumenConfig instance = new LumenConfig();

    // модули
    public boolean esp = true;
    public boolean tracers = true;
    public boolean nametags = true;
    public boolean fullbright = true;

    // фильтры
    public boolean espPlayers = true;
    public boolean espHostile = true;
    public boolean espPassive = false;
    public boolean showInvisible = true;
    public boolean showDistance = true;
    public boolean hud = true;
    public boolean tracersFromCrosshair = false;

    // параметры
    public int range = 128;
    public double fullbrightGamma = 100.0;

    // цвета (hex RRGGBB)
    public String playerColor = "B388FF";
    public String hostileColor = "FF5555";
    public String passiveColor = "55FF99";

    // target ESP / target HUD
    public boolean tesp = true;
    public String tespStyle = "ring"; // ring | box | both
    public String tespColor = "B388FF";
    public boolean thud = true;
    public int thudX = 60;
    public int thudY = 40;
    public float thudScale = 1.0f;
    public String thudStyle = "glass"; // glass | flat
    public String thudColor = "B388FF";
    public boolean thudSkin = true;
    public float targetHold = 4.0f;

    // world visuals
    public boolean world = true;
    public boolean worldFog = true;
    public int fogStart = 8;
    public int fogEnd = 70;
    public String fogColor = "3B1580";
    public boolean worldTime = true;
    public int worldTimeTicks = 16500;
    public String particleType = "snow";
    public int particleCount = 8;
    public String tintColor = "7A3FE0";
    public int tintAlpha = 24;
    public boolean vignette = true;

    public transient int playerArgb, hostileArgb, passiveArgb, tespArgb, thudArgb, fogRgb, tintRgb;

    public static int parseHex(String s) {
        try {
            String h = s.replace("#", "");
            if (h.length() != 6) return -1;
            return Integer.parseInt(h, 16);
        } catch (Exception e) {
            return -1;
        }
    }

    public void resetThud() {
        thud = true; thudX = 60; thudY = 40; thudScale = 1.0f;
        thudStyle = "glass"; thudColor = "B388FF"; thudSkin = true; targetHold = 4.0f;
    }

    public boolean applyPreset(String n) {
        switch (n) {
            case "newyear" -> { world = true; worldFog = true; fogStart = 8; fogEnd = 70; fogColor = "3B1580";
                worldTime = true; worldTimeTicks = 16500; particleType = "snow"; particleCount = 8;
                tintColor = "7A3FE0"; tintAlpha = 24; vignette = true; }
            case "sunset" -> { world = true; worldFog = true; fogStart = 20; fogEnd = 88; fogColor = "C55BD6";
                worldTime = true; worldTimeTicks = 12800; particleType = "sparkle"; particleCount = 3;
                tintColor = "FF8AD8"; tintAlpha = 18; vignette = true; }
            case "aurora" -> { world = true; worldFog = true; fogStart = 15; fogEnd = 80; fogColor = "1B2A6B";
                worldTime = true; worldTimeTicks = 18000; particleType = "magic"; particleCount = 8;
                tintColor = "3AC7A0"; tintAlpha = 14; vignette = true; }
            case "sakura" -> { world = true; worldFog = true; fogStart = 25; fogEnd = 95; fogColor = "F2B5D4";
                worldTime = true; worldTimeTicks = 6000; particleType = "sakura"; particleCount = 4;
                tintColor = "FFC2E2"; tintAlpha = 14; vignette = true; }
            case "off" -> world = false;
            default -> { return false; }
        }
        recolor();
        return true;
    }

    public static LumenConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("lumenvisuals.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                LumenConfig c = GSON.fromJson(Files.readString(p), LumenConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) {
        }
        instance.recolor();
        instance.save();
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }

    public void recolor() {
        playerArgb = parse(playerColor, 0xB388FF);
        hostileArgb = parse(hostileColor, 0xFF5555);
        passiveArgb = parse(passiveColor, 0x55FF99);
        if (range < 8) range = 8;
        tespArgb = parse(tespColor, 0xB388FF);
        thudArgb = parse(thudColor, 0xB388FF);
        fogRgb = parse(fogColor, 0x3B1580) & 0xFFFFFF;
        tintRgb = parse(tintColor, 0x7A3FE0) & 0xFFFFFF;
        thudScale = Math.max(0.5f, Math.min(3f, thudScale));
        fogStart = Math.max(0, Math.min(98, fogStart));
        fogEnd = Math.max(fogStart + 1, Math.min(100, fogEnd));
        tintAlpha = Math.max(0, Math.min(120, tintAlpha));
        particleCount = Math.max(0, Math.min(60, particleCount));
        targetHold = Math.max(0.5f, Math.min(30f, targetHold));
    }

    private static int parse(String s, int def) {
        try {
            return 0xFF000000 | (Integer.parseInt(s.replace("#", ""), 16) & 0xFFFFFF);
        } catch (Exception e) {
            return 0xFF000000 | def;
        }
    }
}
