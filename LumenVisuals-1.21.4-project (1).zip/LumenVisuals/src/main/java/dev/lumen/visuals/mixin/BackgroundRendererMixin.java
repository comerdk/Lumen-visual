package dev.lumen.visuals.mixin;

import dev.lumen.visuals.LumenConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.Fog;
import net.minecraft.entity.effect.StatusEffects;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Свой туман и цвет неба/фона для «World visuals».
 * require = 0: если в версии игры метод называется иначе, мод просто не меняет туман, а не падает.
 */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {

    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true, require = 0)
    private static void lumenvisuals$fog(CallbackInfoReturnable<Fog> cir) {
        LumenConfig c = LumenConfig.get();
        if (!c.world || !c.worldFog) return;
        Fog f = cir.getReturnValue();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (f == null || mc.gameRenderer == null || mc.player == null) return;
        if (mc.gameRenderer.getCamera().getSubmersionType() != CameraSubmersionType.NONE) return;
        if (mc.player.hasStatusEffect(StatusEffects.BLINDNESS) || mc.player.hasStatusEffect(StatusEffects.DARKNESS)) return;

        float r = ((c.fogRgb >> 16) & 255) / 255f;
        float g = ((c.fogRgb >> 8) & 255) / 255f;
        float b = (c.fogRgb & 255) / 255f;

        float start = f.start();
        float end = f.end();
        if (start > 0f) { // туман земли: двигаем дальность; у неба start == 0, там меняем только цвет
            start = end * c.fogStart / 100f;
            end = end * c.fogEnd / 100f;
        }
        cir.setReturnValue(new Fog(start, end, f.shape(), r, g, b, f.alpha()));
    }

    @Inject(method = "getFogColor", at = @At("RETURN"), require = 0)
    private static void lumenvisuals$fogColor(CallbackInfoReturnable<Vector4f> cir) {
        LumenConfig c = LumenConfig.get();
        if (!c.world || !c.worldFog) return;
        Vector4f v = cir.getReturnValue();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (v == null || mc.gameRenderer == null) return;
        if (mc.gameRenderer.getCamera().getSubmersionType() != CameraSubmersionType.NONE) return;
        v.set(((c.fogRgb >> 16) & 255) / 255f, ((c.fogRgb >> 8) & 255) / 255f, (c.fogRgb & 255) / 255f, v.w);
    }
}
