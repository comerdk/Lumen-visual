LUMEN VISUALS — Fabric 1.21.4 (клиентский мод, Java 21)

МЕНЮ: RShift — click GUI в стиле liquid glass (скруглённые сглаженные панели).
  Вкладки: Visuals | Target | World | Theme. Тап по пункту — вкл/выкл, ползунки тянутся пальцем,
  ПКМ по переключателю-списку — предыдущий вариант. Закрыть: RShift или кнопка ×.
КЛАВИШИ: J ESP, K Tracers, U Nametags, L Fullbright (меняются в управлении)

THEME   — цвет темы: палитра, оттенок/насыщенность/яркость, прозрачность стекла, жидкие блики.
          Тема красит меню, HUD (Lumen + список модулей), Target HUD и Target ESP.
WORLD   — пресеты Newyear / Sunset / Aurora / Sakura, насыщенность атмосферы (туман, небо, плазма, оверлей),
          туман, время суток, частицы (snow, sparkle, magic, sakura, ash, glow, electric),
          дым (smoke, large, cozy), небо-плазма (aurora, nebula, solar, toxic: яркость и скорость).
TARGET  — Target ESP (кольцо/бокс) и Target HUD (liquid glass, позиция/размер).

ЧАТ (с точкой или /lumen ...):
  .lumen help
  .theme HEX | .theme hsv H S V | .theme reset
  .thud on|off|x N|y N|scale F|style glass|flat|color HEX|skin on|off|hold SEC|reset
  .tesp on|off|style ring|box|both|color HEX
  .world on|off|preset newyear|sunset|aurora|sakura|off|sat 0-200
  .world fog <старт%> <конец%> | fogcolor HEX | time day|sunset|night|0-24000|off
  .world particles snow|sparkle|magic|sakura|ash|glow|electric|off | count N
  .world smoke smoke|large|cozy|off [N] | plasma aurora|nebula|solar|toxic|off [яркость] | plasmaspeed N
  .world tint HEX [альфа] | vignette on|off

Настройки: config/lumenvisuals.json

СБОРКА: залить zip в репозиторий GitHub (workflow build.yml уже есть) -> Actions -> Artifacts.
