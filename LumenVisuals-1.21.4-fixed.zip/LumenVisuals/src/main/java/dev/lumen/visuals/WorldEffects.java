package dev.lumen.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import java.util.Random;

/**
 * «Красивый мир»: время суток, частицы и дым вокруг игрока, цветной оверлей, виньетка и небо-плазма.
 * Туман и цвет фона — в BackgroundRendererMixin (берёт цвет из fogRgb()).
 */
public final class WorldEffects {
    private static final Random RNG = new Random();
    private static final int[] AURORA = {0x2BFF9A, 0x35C7FF, 0xB05CFF};
    private static final int[] NEBULA = {0x7A3FE0, 0xFF5AD1, 0x4A6BFF};
    private static final int[] SOLAR = {0xFF7A18, 0xFF2E93, 0xFFD23F};
    private static final int[] TOXIC = {0x7CFF00, 0x00FFA3, 0xE6FF3F};

    private static float plasmaFade;
    private static long lastNs = System.nanoTime();

    private WorldEffects() {}

    /** Раз в кадр: фиксируем время суток (сервер его сбрасывает, поэтому каждый кадр). */
    public static void frame(MinecraftClient mc) {
        LumenConfig c = LumenConfig.get();
        if (!c.world || !c.worldTime || mc.world == null) return;
        mc.world.getLevelProperties().setTimeOfDay(c.worldTimeTicks);
    }

    /** Раз в тик: частицы и дым вокруг игрока. */
    public static void tick(MinecraftClient mc) {
        LumenConfig c = LumenConfig.get();
        if (!c.world || mc.world == null || mc.player == null || mc.isPaused()) return;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();

        ParticleEffect fx = c.particleCount > 0 ? effect(c.particleType) : null;
        if (fx != null) {
            boolean falling = c.particleType.equals("snow") || c.particleType.equals("sakura") || c.particleType.equals("ash");
            for (int i = 0; i < c.particleCount; i++) {
                double x = px + (RNG.nextDouble() - 0.5) * 28;
                double y = py + RNG.nextDouble() * 9 - 1;
                double z = pz + (RNG.nextDouble() - 0.5) * 28;
                double vy = falling ? -0.03 - RNG.nextDouble() * 0.03 : (RNG.nextDouble() - 0.3) * 0.02;
                mc.world.addParticle(fx, x, y, z, (RNG.nextDouble() - 0.5) * 0.02, vy, (RNG.nextDouble() - 0.5) * 0.02);
            }
        }

        ParticleEffect sm = c.smokeCount > 0 ? smoke(c.smokeType) : null;
        if (sm != null) {
            for (int i = 0; i < c.smokeCount; i++) {
                double x = px + (RNG.nextDouble() - 0.5) * 24;
                double y = py + RNG.nextDouble() * 2.5 - 0.5;
                double z = pz + (RNG.nextDouble() - 0.5) * 24;
                mc.world.addParticle(sm, x, y, z, (RNG.nextDouble() - 0.5) * 0.01, 0.02 + RNG.nextDouble() * 0.02, (RNG.nextDouble() - 0.5) * 0.01);
            }
        }
    }

    /** Цветной оверлей, виньетка и небо-плазма. */
    public static void overlay(DrawContext c, MinecraftClient mc, LumenConfig cfg) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1_000_000_000f);
        lastNs = now;
        if (!cfg.world) {
            plasmaFade = 0f;
            return;
        }
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float sat = cfg.worldSat / 100f;

        if (cfg.tintAlpha > 0) {
            c.fill(0, 0, sw, sh, (cfg.tintAlpha << 24) | Gfx.saturate(cfg.tintRgb, sat));
        }
        if (cfg.vignette) {
            int h = sh / 5;
            c.fillGradient(0, 0, sw, h, 0x66100430, 0x00100430);
            c.fillGradient(0, sh - h, sw, sh, 0x00100430, 0x66100430);
        }
        plasma(c, mc, cfg, sw, sh, dt, sat);
    }

    /** Небо-плазма: переливающиеся «занавесы» над линией горизонта. */
    private static void plasma(DrawContext c, MinecraftClient mc, LumenConfig cfg, int sw, int sh, float dt, float sat) {
        boolean on = plasmaActive(cfg)
                && mc.world != null && mc.player != null
                && mc.world.getRegistryKey() == World.OVERWORLD
                && mc.world.isSkyVisible(mc.player.getBlockPos());
        plasmaFade += ((on ? 1f : 0f) - plasmaFade) * Math.min(1f, dt * 3f);
        if (plasmaFade < 0.02f) return;

        float hy = VisualsRenderer.horizonY(sw, sh);
        if (Float.isNaN(hy) || hy < 8f) return;
        hy = Math.min(hy, sh);

        double t = (System.currentTimeMillis() % 3_600_000L) / 1000.0 * (cfg.plasmaSpeed / 100.0);
        float k = plasmaFade * cfg.plasmaIntensity / 100f;
        int strip = 6;
        for (int x = 0; x < sw; x += strip) {
            float u = x / (float) sw;
            float w1 = (float) Math.sin(u * 9.0 + t * 0.9);
            float w2 = (float) Math.sin(u * 4.3 - t * 0.6);
            float w3 = (float) Math.sin(u * 17.0 + t * 1.7) * 0.3f;
            float wave = MathHelper.clamp((w1 + w2 + w3) * 0.3f + 0.5f, 0f, 1f);
            float tt = 0.5f + 0.5f * (float) Math.sin(u * 5.0 + t * 0.4);
            int colA = Gfx.saturate(plasmaRgb(cfg.plasma, tt), sat);
            int colB = Gfx.saturate(plasmaRgb(cfg.plasma, 1f - tt), sat);
            int bottom = (int) (hy * (0.5f + 0.5f * wave));
            int mid = bottom / 2;
            if (mid < 2) continue;
            int aMax = (int) (255 * k * (0.12f + 0.38f * wave));
            c.fillGradient(x, 0, x + strip, mid, Gfx.withA(colB, 0), Gfx.withA(colB, aMax));
            c.fillGradient(x, mid, x + strip, bottom, Gfx.withA(colA, aMax), Gfx.withA(colA, 0));
        }
    }

    public static boolean plasmaActive(LumenConfig c) {
        return !"off".equals(c.plasma) && c.plasmaIntensity > 0;
    }

    /** Итоговый цвет тумана/фона: заданный цвет с учётом насыщенности и «дыхания» плазмы. */
    public static int fogRgb(LumenConfig c) {
        float sat = c.worldSat / 100f;
        int base = Gfx.saturate(c.fogRgb, sat);
        if (plasmaActive(c)) {
            double t = (System.currentTimeMillis() % 3_600_000L) / 1000.0 * (c.plasmaSpeed / 100.0);
            float tt = 0.5f + 0.5f * (float) Math.sin(t * 0.35);
            int p = Gfx.saturate(plasmaRgb(c.plasma, tt), sat);
            base = Gfx.mixRgb(base, p, 0.65f * c.plasmaIntensity / 100f);
        }
        return base;
    }

    private static int plasmaRgb(String variant, float t) {
        int[] p = switch (variant) {
            case "aurora" -> AURORA;
            case "solar" -> SOLAR;
            case "toxic" -> TOXIC;
            default -> NEBULA;
        };
        return t < 0.5f ? Gfx.mixRgb(p[0], p[1], t * 2f) : Gfx.mixRgb(p[1], p[2], (t - 0.5f) * 2f);
    }

    private static ParticleEffect effect(String name) {
        return switch (name) {
            case "snow" -> ParticleTypes.SNOWFLAKE;
            case "sparkle" -> ParticleTypes.END_ROD;
            case "magic" -> ParticleTypes.ENCHANT;
            case "sakura" -> ParticleTypes.CHERRY_LEAVES;
            case "ash" -> ParticleTypes.WHITE_ASH;
            case "glow" -> ParticleTypes.GLOW;
            case "electric" -> ParticleTypes.ELECTRIC_SPARK;
            default -> null;
        };
    }

    private static ParticleEffect smoke(String name) {
        return switch (name) {
            case "large" -> ParticleTypes.LARGE_SMOKE;
            case "cozy" -> ParticleTypes.CAMPFIRE_COSY_SMOKE;
            default -> ParticleTypes.SMOKE;
        };
    }
}
